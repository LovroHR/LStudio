<?php
session_start();
$conn = new mysqli("localhost", "root", "", "lstudio baza");

if ($conn->connect_error) {
    die("Neuspjelo povezivanje na bazu: " . $conn->connect_error);
}

$id = (int)$_GET['id'];
$itemResult = $conn->query("SELECT * FROM portfolio_items WHERE id = $id");
if (!$itemResult || $itemResult->num_rows === 0) {
    die("Stavka ne postoji.");
}
$item = $itemResult->fetch_assoc();

$images = $conn->query("SELECT * FROM portfolio_images WHERE portfolio_item_id = $id");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);
    $conn->query("UPDATE portfolio_items SET title = '$title', description = '$description' WHERE id = $id");

    $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'svg'];
    $allowedMimeTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/bmp', 'image/svg+xml'];

    if (!is_dir('uploads/portfolio')) {
        mkdir('uploads/portfolio', 0775, true);
    }

    foreach ($_FILES['images']['tmp_name'] as $index => $tmpPath) {
        if (isset($_FILES['images']['error'][$index]) && $_FILES['images']['error'][$index] === 0) {
            $fileName = $_FILES['images']['name'][$index];
            $fileTmp = $_FILES['images']['tmp_name'][$index];
            $fileType = mime_content_type($fileTmp);
            $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

            if (in_array($fileExt, $allowedExtensions) && in_array($fileType, $allowedMimeTypes)) {
                $imageName = time() . '_' . uniqid() . '.' . $fileExt;
                $destination = "uploads/portfolio/$imageName";

                if (move_uploaded_file($fileTmp, $destination)) {
                    $destinationEsc = $conn->real_escape_string($destination);
                    $conn->query("INSERT INTO portfolio_images (portfolio_item_id, image_path) VALUES ($id, '$destinationEsc')");
                }
            }
        }
    }

    header("Location: portfolio_edit.php?id=$id");
    exit;
}
?>

<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body class="d-flex flex-column min-vh-100">
<?php include 'nav.php'; ?>

<div class="container py-5">
    <h1>Uredi stavku</h1>
    <form method="post" enctype="multipart/form-data">
        <div class="mb-3">
            <label class="form-label">Naslov</label>
            <input type="text" name="title" class="form-control" value="<?= htmlspecialchars($item['title']) ?>" required>
        </div>
        <div class="mb-3">
            <label class="form-label">Opis</label>
            <textarea name="description" class="form-control" rows="4"><?= htmlspecialchars($item['description']) ?></textarea>
        </div>
        <div class="mb-3">
            <label class="form-label">Dodaj nove fotografije</label>
            <input type="file" name="images[]" class="form-control" multiple accept="image/*">
        </div>

        <div class="mb-3">
            <label class="form-label">Postojeće fotografije</label>
            <div class="row">
                <?php while ($img = $images->fetch_assoc()): ?>
                    <div class="col-md-3 mb-2">
                        <img src="/bootstrap/<?= htmlspecialchars($img['image_path']) ?>" class="img-fluid rounded" alt="Slika">
                    </div>
                <?php endwhile; ?>
            </div>
        </div>

        <button type="submit" class="btn btn-success">Spremi izmjene</button>
    </form>
</div>

<?php include 'footer.php'; ?>
</body>
</html>

<?php
$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška kod povezivanja s bazom: " . $conn->connect_error);
}

$sql = "SELECT * FROM news ORDER BY post_date DESC";
$result = $conn->query($sql);

$newsList = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $newsList[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<body class="d-flex flex-column">
<main class="flex-shrink-0">
    <?php include 'nav.php'; ?>

    <section class="py-5">
        <div class="container px-5">
            <h1 class="fw-bolder fs-5 mb-4">Vijesti</h1>
            <?php if (count($newsList) > 0): ?>
                <?php
                $featured = $newsList[0];
                $categories = array_filter(array_map('trim', explode(',', $featured['categories'])));
                ?>
                <div class="card border-0 shadow rounded-3 overflow-hidden mb-5">
                    <div class="card-body p-0">
                        <div class="row gx-0">
                            <div class="col-lg-6 col-xl-5 py-lg-5">
                                <div class="p-4 p-md-5">
                                    <div class="badge bg-primary bg-gradient rounded-pill mb-2">
                                        <?= htmlspecialchars($categories[0] ?? 'News') ?>
                                    </div>
                                    <div class="h2 fw-bolder" style="white-space: normal; word-wrap: break-word;">
                                        <?= htmlspecialchars($featured['title']) ?>
                                    </div>
                                    <p><?= nl2br(htmlspecialchars(substr($featured['content'], 0, 150))) ?>...</p>
                                    <a class="stretched-link text-decoration-none" href="blog-post.php?id=<?= $featured['id'] ?>">
                                        Read more <i class="bi bi-arrow-right"></i>
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-6 col-xl-7">
                                <?php if (!empty($featured['image_path'])): ?>
                                    <div class="bg-featured-blog" style="background-image: url('<?= htmlspecialchars($featured['image_path']) ?>'); height: 100%; background-size: cover; background-position: center;"></div>
                                <?php else: ?>
                                    <div class="bg-featured-blog" style="background-image: url('https://dummyimage.com/700x350/343a40/6c757d'); height: 100%;"></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <section class="py-5 position-relative">
        <div class="container px-5">
            <h2 class="fw-bolder fs-5 mb-4">Više vijesti</h2>

            <div class="overflow-auto position-relative px-4 pb-4" style="white-space: nowrap;">
                <div class="d-flex flex-nowrap gap-4">
                    <?php
                    foreach (array_slice($newsList, 1, 10) as $news):
                        $categories = array_filter(array_map('trim', explode(',', $news['categories'])));
                    ?>
                    <div class="card h-100 shadow border-0" style="width: 300px; flex: 0 0 auto;">
                        <?php if (!empty($news['image_path'])): ?>
                            <img class="card-img-top" src="<?= htmlspecialchars($news['image_path']) ?>" alt="..." style="height: 200px; object-fit: cover;" />
                        <?php else: ?>
                            <img class="card-img-top" src="https://dummyimage.com/600x350/ced4da/6c757d" alt="..." style="height: 200px; object-fit: cover;" />
                        <?php endif; ?>
                        <div class="card-body p-3">
                            <div class="badge bg-primary bg-gradient rounded-pill mb-2"><?= htmlspecialchars($categories[0] ?? 'News') ?></div>
                            <a class="text-decoration-none link-dark stretched-link" href="blog-post.php?id=<?= $news['id'] ?>">
                                <div class="h6 card-title mb-2" style="
                                    display: -webkit-box;
                                    -webkit-line-clamp: 2;
                                    -webkit-box-orient: vertical;
                                    overflow: hidden;
                                    white-space: normal;
                                    word-wrap: break-word;
                                ">
                                    <?= htmlspecialchars($news['title']) ?>
                                </div>
                            </a>
                            <p class="card-text small mb-0" style="display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;">
                                <?= htmlspecialchars($news['content']) ?>
                            </p>
                        </div>
                        <div class="card-footer p-3 pt-0 bg-transparent border-top-0">
                            <div class="d-flex align-items-center">
                                <img class="rounded-circle me-2" src="https://dummyimage.com/40x40/ced4da/6c757d" alt="..." />
                                <div class="small">
                                    <div class="fw-bold"><?= htmlspecialchars($news['author']) ?></div>
                                    <div class="text-muted"><?= date("F j, Y", strtotime($news['post_date'])) ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="fade-start position-absolute top-0 start-0 h-100" style="width: 60px; pointer-events: none;"></div>
                <div class="fade-end position-absolute top-0 end-0 h-100" style="width: 60px; pointer-events: none;"></div>
            </div>

            <div class="text-end mt-4">
                <a class="text-decoration-none" href="blog-all.php">
                    Arhiva vijesti <i class="bi bi-arrow-right"></i>
                </a>
            </div>
        </div>
    </section>

</main>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>
<?php $conn->close(); ?>

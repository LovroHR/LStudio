<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$title = $author = $categories = $post_date = $content = $image_path = "";
$errors = [];

if ($id > 0) {
    $stmt = $conn->prepare("SELECT * FROM news WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 1) {
        $news = $result->fetch_assoc();
        $title = $news['title'];
        $author = $news['author'];
        $categories = $news['categories'];
        $post_date = date("Y-m-d", strtotime($news['post_date']));
        $content = $news['content'];
        $image_path = $news['image_path'];
    } else {
        $errors[] = "Vijest nije pronađena.";
    }
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $categories = trim($_POST['categories'] ?? '');
    $post_date = trim($_POST['post_date'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $new_image_path = $image_path;

    if ($title === '') $errors[] = "Naslov je obavezan.";
    if ($author === '') $errors[] = "Autor je obavezan.";
    if ($post_date === '') $errors[] = "Datum objave je obavezan.";
    if ($content === '') $errors[] = "Sadržaj je obavezan.";

    if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = "Greška pri uploadu slike.";
        } elseif (!in_array($_FILES['image']['type'], $allowed_types)) {
            $errors[] = "Dozvoljeni formati su JPEG, PNG, GIF.";
        } else {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $new_filename = uniqid('img_', true) . "." . $ext;
            $upload_dir = __DIR__ . '/uploads/';

            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            $destination = $upload_dir . $new_filename;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                $new_image_path = 'uploads/' . $new_filename;
            } else {
                $errors[] = "Neuspješan pokušaj spremanja slike.";
            }
        }
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("UPDATE news SET title=?, author=?, categories=?, post_date=?, content=?, image_path=? WHERE id=?");
        $stmt->bind_param("ssssssi", $title, $author, $categories, $post_date, $content, $new_image_path, $id);

        if ($stmt->execute()) {
            header("Location: cms.php");
            exit;
        } else {
            $errors[] = "Greška pri spremanju u bazu: " . $conn->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body class="d-flex flex-column min-vh-100">
<main class="flex-shrink-0">
    <?php include 'nav.php'; ?>
    <section class="py-5">
        <div class="container px-5 my-5">
            <h1>Uredi vijest</h1>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="post" enctype="multipart/form-data" novalidate>
                <div class="mb-3">
                    <label for="title" class="form-label">Naslov</label>
                    <input type="text" name="title" id="title" class="form-control" value="<?= htmlspecialchars($title) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="author" class="form-label">Autor</label>
                    <input type="text" name="author" id="author" class="form-control" value="<?= htmlspecialchars($author) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="categories" class="form-label">Kategorije</label>
                    <input type="text" name="categories" id="categories" class="form-control" value="<?= htmlspecialchars($categories) ?>">
                </div>
                <div class="mb-3">
                    <label for="post_date" class="form-label">Datum objave</label>
                    <input type="date" name="post_date" id="post_date" class="form-control" value="<?= htmlspecialchars($post_date) ?>" required>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Slika vijesti (JPEG, PNG, GIF)</label>
                    <input type="file" name="image" id="image" class="form-control" accept="image/*">
                    <div class="mt-2">
                        <p>Pregled slike:</p>
                        <img id="imagePreview" src="<?= htmlspecialchars($image_path) ?>" alt="Pregled slike" style="max-height: 200px; <?= $image_path ? '' : 'display:none;' ?>">
                    </div>
                </div>
                <div class="mb-3">
                    <label for="content" class="form-label">Sadržaj</label>
                    <textarea name="content" id="content" class="form-control" rows="8" required><?= htmlspecialchars($content) ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Spremi promjene</button>
                <a href="cms.php" class="btn btn-secondary ms-2">Odustani</a>
            </form>
        </div>
    </section>
</main>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script>

document.getElementById('image').addEventListener('change', function (event) {
    const preview = document.getElementById('imagePreview');
    const file = event.target.files[0];

    if (file && file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = function (e) {
            preview.src = e.target.result;
            preview.style.display = 'block';
        };
        reader.readAsDataURL(file);
    }
});
</script>
<script src="js/scripts.js"></script>
</body>
</html>

<?php
$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$items_per_page = 6;
$total_projects_result = $conn->query("SELECT COUNT(*) AS total FROM portfolio_items");
$total_projects_row = $total_projects_result->fetch_assoc();
$total_projects = $total_projects_row['total'];

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $items_per_page;

$stmt = $conn->prepare("SELECT id, title FROM portfolio_items ORDER BY created_at DESC LIMIT ? OFFSET ?");
$stmt->bind_param("ii", $items_per_page, $offset);
$stmt->execute();
$result = $stmt->get_result();

$projects = [];
while ($row = $result->fetch_assoc()) {
    $projects[] = $row;
}

$stmt->close();
$conn->close();

$total_pages = ceil($total_projects / $items_per_page);
?>

<!DOCTYPE html>
<html lang="en">
    <?php include 'head.php'; ?>
    <body class="d-flex flex-column h-100">
        <main class="flex-shrink-0">

            <?php include 'nav.php'; ?>

            <section class="py-5">
                <div class="container px-5 my-5">
                    <div class="text-center mb-5">
                        <h1 class="fw-bolder">Naši projekti</h1>
                        <p class="lead fw-normal text-muted mb-0">Budite i Vi dio našeg portfolia</p>
                    </div>
                    <div class="row gx-5">
                        <?php foreach ($projects as $project): ?>
                            <?php
                                $conn = new mysqli("localhost", "root", "", "lstudio baza");
                                $img = get_first_image($conn, $project['id']);
                                $conn->close();

                                if (!$img) {
                                    $img = "https://dummyimage.com/600x400/343a40/6c757d";
                                }
                            ?>
                            <div class="col-lg-6">
                                <div class="position-relative mb-5">
                                    <a href="portfolio-item.php?id=<?= htmlspecialchars($project['id']) ?>" class="stretched-link text-decoration-none">
                                        <div class="image-wrapper mb-3">
                                            <img class="project-image" src="<?= htmlspecialchars($img) ?>" alt="<?= htmlspecialchars($project['title']) ?>" />
                                        </div>
                                        <h3 class="fw-bolder link-dark"><?= htmlspecialchars($project['title']) ?></h3>
                                    </a>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($total_pages > 1): ?>
                    <nav aria-label="Page navigation example">
                        <ul class="pagination justify-content-center">
                            <?php for ($p = 1; $p <= $total_pages; $p++): ?>
                                <li class="page-item <?= ($p == $page) ? 'active' : '' ?>">
                                    <a class="page-link" href="?page=<?= $p ?>"><?= $p ?></a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                    <?php endif; ?>

                </div>
            </section>
        </main>

        <?php include 'footer.php'; ?>

        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>

        <style>
            
        </style>
    </body>
</html>

<?php


function get_first_image($conn, $project_id) {
    $stmt = $conn->prepare("SELECT image_path FROM portfolio_images WHERE portfolio_item_id = ? ORDER BY id ASC LIMIT 1");
    $stmt->bind_param("i", $project_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $img = $result->fetch_assoc();
    $stmt->close();
    return $img ? $img['image_path'] : false;
}
?>

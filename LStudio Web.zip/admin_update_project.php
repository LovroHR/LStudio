<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$project_id = isset($_GET['project_id']) ? intval($_GET['project_id']) : 0;

if ($project_id <= 0) {
    echo "<div class='container mt-5'><div class='alert alert-danger'>Nevažeći ID projekta.</div></div>";
    include 'footer.php';
    exit;
}

$stmt = $conn->prepare("SELECT * FROM projects WHERE id = ?");
$stmt->bind_param("i", $project_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    echo "<div class='container mt-5'><div class='alert alert-danger'>Projekt nije pronađen.</div></div>";
    include 'footer.php';
    exit;
}

$project = $result->fetch_assoc();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body>
<?php include 'nav.php'; ?>

<div class="container mt-5">
    <h2>Uredi projekt</h2>
    <form method="POST" action="admin_update_project_process.php">
        <input type="hidden" name="project_id" value="<?= $project['id'] ?>">

        <div class="mb-3">
            <label for="title" class="form-label">Naslov</label>
            <input type="text" class="form-control" name="title" id="title" value="<?= htmlspecialchars($project['title']) ?>" required>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Opis</label>
            <textarea class="form-control" name="description" id="description" rows="4" required><?= htmlspecialchars($project['description']) ?></textarea>
        </div>

        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select class="form-select" name="status" id="status">
                <option value="active" <?= $project['status'] === 'active' ? 'selected' : '' ?>>Aktivan</option>
                <option value="completed" <?= $project['status'] === 'completed' ? 'selected' : '' ?>>Završen</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Spremi promjene</button>
        <a href="admin_dash.php" class="btn btn-secondary">Natrag</a>
    </form>
</div>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>

<?php
session_start();

$newsletterMessage = '';
if (isset($_SESSION['newsletterMessage'])) {
    $newsletterMessage = $_SESSION['newsletterMessage'];
    unset($_SESSION['newsletterMessage']);
}
?>
<!DOCTYPE html>
<html lang="en">
    <?php include 'head.php'; ?>
    <body class="d-flex flex-column h-100">
        <main class="flex-shrink-0">
            <?php include 'nav.php'; ?>

            <header class="bg-dark py-5">
                <div class="container px-5">
                    <div class="row gx-5 align-items-center justify-content-center">
                        <div class="col-lg-8 col-xl-7 col-xxl-6">
                            <div class="my-5 text-center text-xl-start">
                                <h1 class="display-5 fw-bolder text-white mb-2">Profesionalna multimedijska rješenja!</h1>
                                <p class="lead fw-normal text-white-50 mb-4">Vaš GO-TO partner za izradu videa, fotografija i zvuka na najvišem mogućem nivou!</p>
                                <div class="d-grid gap-3 d-sm-flex justify-content-sm-center justify-content-xl-start">
                                    <a class="btn btn-primary btn-lg px-4 me-sm-3" href="#features">Saznajte više!</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-5 col-xxl-6 d-none d-xl-block text-center">
                            <img class="img-fluid rounded-3 my-5" src="assets/naslovna1.jpg" alt="Multimedijska rješenja" />
                        </div>
                    </div>
                </div>
            </header>

            <section class="py-5" id="features">
                <div class="container px-5 my-5">
                    <div class="row gx-5">
                        <div class="col-lg-4 mb-5 mb-lg-0">
                            <h2 class="fw-bolder mb-0">Sve što vam treba na jednom mjestu.</h2>
                        </div>
                        <div class="col-lg-8">
                            <div class="row gx-5 row-cols-1 row-cols-md-2">
                                <div class="col mb-5 h-100">
                                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-camera-reels"></i></div>
                                    <h2 class="h5">Video</h2>
                                    <p class="mb-0">Vršimo snimanja događaja, reklama, serija, filmova. Od manje zahtjevnih projekata za društvene mreže, do srednjih i većih filmskih produkcija. Od početka do finalnog proizvoda.</p>
                                </div>
                                <div class="col mb-5 h-100">
                                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-camera"></i></div>
                                    <h2 class="h5">Fotografija</h2>
                                    <p class="mb-0">Izlazimo na teren za fotografiranje događaja (vjenčanja, rođendani, koncerti). Vršimo fotografiranje u studijskim uvjetima, portreti, proizvodi i sl. uz finalnu obradu svih fotografija.</p>
                                </div>
                                <div class="col mb-5 mb-md-0 h-100">
                                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-speaker"></i></div>
                                    <h2 class="h5">Zvuk</h2>
                                    <p class="mb-0">Naš studio opremljen je primarno za snimanje te mix i master glazbe. Mogućnost iznajmljivanja prostora vanjskim suradnicima. Takđer, naš ogranak za obradu zvuka savršeno surađuje sa video timom tako da svaki video dobiva zvuk obrađen na profesionalnom nivou.</p>
                                </div>
                                <div class="col h-100">
                                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-share"></i></div>
                                    <h2 class="h5">Distribucija</h2>
                                    <p class="mb-0">Kao dodatnu uslugu vršimo distribuciju proizvoda po raznim kanalima (streaming glazbe, društvene mreže) ili izdavačkim kućama.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div class="py-5 bg-light">
                <div class="container px-5 my-5">
                    <div class="row gx-5 justify-content-center">
                        <div class="col-lg-10 col-xl-7">
                            <div class="text-center">
                                <div class="fs-4 mb-4 fst-italic">"Doslovno savršen partner za apsolutno svaki posao u multimediji. Najveći adut im je da sve rade "in-house", opremljeni su i kompetentni za sve moguće zadatke i izazove. Uvijek naprave odličan posao!"</div>
                                <div class="d-flex align-items-center justify-content-center">
                                    <img class="rounded-circle me-3" src="assets/review_ceo.jpg" width="40" alt="Ivan Horvat" />
                                    <div class="fw-bold">
                                        Ivan Horvat
                                        <span class="fw-bold text-primary mx-1">/</span>
                                        CEO, TalentGroup
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <section class="py-5">
                <div class="container px-5 my-5">
                    <div class="row gx-5 justify-content-center">
                        <div class="col-lg-8 col-xl-6">
                        </div>
                    </div>

                    <div class="row gx-5">
                        <?php
                        $conn = new mysqli("localhost", "root", "", "lstudio baza");
                        if ($conn->connect_error) {
                            die("Greška u povezivanju s bazom: " . $conn->connect_error);
                        }

                        $sql = "SELECT id, title, author, categories, post_date, image_path, content FROM news ORDER BY post_date DESC LIMIT 3";
                        $result = $conn->query($sql);

                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <div class="col-lg-4 mb-5">
                                    <div class="card h-100 shadow border-0">
                                        <?php if (!empty($row['image_path'])): ?>
                                            <img class="card-img-top news-image" style="width: 100% !important; height: 240px !important; object-fit: cover !important;" src="<?= htmlspecialchars($row['image_path']) ?>" alt="<?= htmlspecialchars($row['title']) ?>" />
                                        <?php endif; ?>
                                        <div class="card-body p-4">
                                            <div class="badge bg-primary bg-gradient rounded-pill mb-2"><?= htmlspecialchars($row['categories']) ?></div>
                                            <a class="text-decoration-none link-dark stretched-link" href="blog-post.php?id=<?= $row['id'] ?>">
                                                <h5 class="card-title mb-3"><?= htmlspecialchars($row['title']) ?></h5>
                                            </a>
                                            <p class="card-text mb-0"><?= htmlspecialchars(mb_strimwidth($row['content'], 0, 100, "...")) ?></p>
                                        </div>
                                        <div class="card-footer p-4 pt-0 bg-transparent border-top-0">
                                            <div class="d-flex align-items-end justify-content-between">
                                                <div class="d-flex align-items-center">
                                                    <img class="rounded-circle me-3" src="https://dummyimage.com/40x40/ced4da/6c757d" alt="Author avatar" />
                                                    <div class="small">
                                                        <div class="fw-bold"><?= htmlspecialchars($row['author']) ?></div>
                                                        <div class="text-muted"><?= date('F j, Y', strtotime($row['post_date'])) ?> &middot; ~<?= round(strlen($row['content']) / 5 / 60) ?> min read</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                        } else {
                            echo '<p class="text-center">Nema dostupnih vijesti.</p>';
                        }
                        $conn->close();
                        ?>
                    </div>

                    <aside class="bg-primary bg-gradient rounded-3 p-4 p-sm-5 mt-5">
                        <div class="d-flex align-items-center justify-content-between flex-column flex-xl-row text-center text-xl-start">
                            <div class="mb-4 mb-xl-0">
                                <div class="fs-3 fw-bold text-white">Ostanite u toku.</div>
                                <div class="text-white-50">Prijavite se na naš newsletter za sve važne vijesti.</div>
                            </div>
                            <div class="ms-xl-4">
                                <form method="POST" class="input-group mb-2" action="newsletter_subscribe.php">
                                    <input 
                                        class="form-control" 
                                        type="email" 
                                        name="newsletter_email" 
                                        placeholder="Email adresa..." 
                                        aria-label="Email adresa..." 
                                        aria-describedby="button-newsletter" 
                                        required
                                    />
                                    <button class="btn btn-outline-light" id="button-newsletter" type="submit">Prijavi se!</button>
                                </form>

                                <?= $newsletterMessage ?>

                                <div class="small text-white-50">Nikada nećemo dijeliti Vaše podatke. Stalno nam je do privatnosti.</div>
                            </div>
                        </div>
                    </aside>
                </div>
            </section>

        </main>

        <!-- Footer-->
        <?php include 'footer.php'; ?>

        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $phone = htmlspecialchars($_POST['phone']);
    $message = htmlspecialchars($_POST['message']);

    if ($name && $email && $phone && $message) {
        $to = "you@example.com";
        $subject = "Nova poruka s kontakt forme";
        $body = "Ime: $name\nEmail: $email\nTelefon: $phone\n\nPoruka:\n$message";
        $headers = "From: $email";

        if (mail($to, $subject, $body, $headers)) {
            echo "Poruka je uspješno poslana.";
        } else {
            echo "Greška prilikom slanja poruke.";
        }
    } else {
        echo "Sva polja su obavezna!";
    }
}
?>

<?php
session_start();

if (!isset($_SESSION['user']['email'])) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$currentEmail = $_SESSION['user']['email'];

$name = trim($_POST['name']);
$surname = trim($_POST['surname']);
$email = trim($_POST['email']);
$password = $_POST['password'];
$dateOfBirth = $_POST['dateOfBirth'];
$phone = trim($_POST['phone']);
$address = trim($_POST['address']);
$city = trim($_POST['city']);
$country = trim($_POST['country']);

if (empty($name) || empty($surname) || empty($email) || empty($dateOfBirth)) {
    die("Ime, prezime, email i datum rođenja su obavezni podaci.");
}

if ($email !== $currentEmail) {
    $stmtCheck = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $stmtCheck->bind_param("s", $email);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();
    if ($resultCheck->num_rows > 0) {
        die("Email adresa je već zauzeta.");
    }
    $stmtCheck->close();
}

$stmtRole = $conn->prepare("SELECT role FROM users WHERE email = ?");
$stmtRole->bind_param("s", $currentEmail);
$stmtRole->execute();
$resultRole = $stmtRole->get_result();
if ($resultRole->num_rows !== 1) {
    die("Korisnik nije pronađen za dohvat role.");
}
$rowRole = $resultRole->fetch_assoc();
$role = $rowRole['role'];
$stmtRole->close();

if (!empty($password)) {
    $passwordHashed = password_hash($password, PASSWORD_DEFAULT);
} else {
    $stmtPass = $conn->prepare("SELECT password FROM users WHERE email = ?");
    $stmtPass->bind_param("s", $currentEmail);
    $stmtPass->execute();
    $resultPass = $stmtPass->get_result();
    if ($resultPass->num_rows !== 1) {
        die("Korisnik nije pronađen za dohvat lozinke.");
    }
    $rowPass = $resultPass->fetch_assoc();
    $passwordHashed = $rowPass['password'];
    $stmtPass->close();
}

$sql = "UPDATE users SET name=?, surname=?, email=?, password=?, dateOfBirth=?, phone=?, address=?, city=?, country=?, role=? WHERE email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssssssssss", $name, $surname, $email, $passwordHashed, $dateOfBirth, $phone, $address, $city, $country, $role, $currentEmail);

if ($stmt->execute()) {
    // Ažuriraj sesiju
    $_SESSION['user'] = [
        'name' => $name,
        'surname' => $surname,
        'email' => $email,
        'dateOfBirth' => $dateOfBirth,
        'phone' => $phone,
        'address' => $address,
        'city' => $city,
        'country' => $country,
        'role' => $role
    ];

    header("Location: user.php?msg=Profil uspješno ažuriran");
    exit;
} else {
    echo "Greška prilikom ažuriranja profila: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>

<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
$title = trim($_POST['title']);
$description = trim($_POST['description']);
$status = ($_POST['status'] === 'completed') ? 'completed' : 'active';
$created_at = date('Y-m-d H:i:s');

if (empty($user_id) || empty($title) || empty($description)) {
    die("Svi podaci su obavezni.");
}

$stmtCheck = $conn->prepare("SELECT id FROM users WHERE id = ? AND role = 'user'");
$stmtCheck->bind_param("i", $user_id);
$stmtCheck->execute();
$resultCheck = $stmtCheck->get_result();

if ($resultCheck->num_rows !== 1) {
    die("Korisnik nije pronađen.");
}
$stmtCheck->close();

$stmtInsert = $conn->prepare("INSERT INTO projects (user_id, title, description, status, created_at) VALUES (?, ?, ?, ?, ?)");
$stmtInsert->bind_param("issss", $user_id, $title, $description, $status, $created_at);

if ($stmtInsert->execute()) {
    header("Location: admin_dash.php?msg=Projekt uspješno dodan");
    exit;
} else {
    echo "Greška pri unosu projekta: " . $conn->error;
}

$stmtInsert->close();
$conn->close();
?>

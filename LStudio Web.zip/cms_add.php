<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $categories = trim($_POST['categories'] ?? '');
    $post_date = trim($_POST['post_date'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $image_path = null;


    if ($title === '') $errors[] = "Naslov je obavezan.";
    if ($author === '') $errors[] = "Autor je obavezan.";
    if ($post_date === '') $errors[] = "Datum objave je obavezan.";
    if ($content === '') $errors[] = "Sadržaj vijesti je obavezan.";

    if (isset($_FILES['image']) && $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = "Greška pri uploadu slike.";
        } elseif (!in_array($_FILES['image']['type'], $allowed_types)) {
            $errors[] = "Dozvoljeni formati slike su JPEG, PNG i GIF.";
        } else {
            $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
            $new_filename = uniqid('img_', true) . "." . $ext;
            $upload_dir = __DIR__ . '/uploads/';

            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0755, true);
            }

            $destination = $upload_dir . $new_filename;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $destination)) {
                $image_path = 'uploads/' . $new_filename;
            } else {
                $errors[] = "Neuspješan pokušaj spremanja slike na server.";
            }
        }
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO news (title, author, categories, post_date, image_path, content) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $title, $author, $categories, $post_date, $image_path, $content);

        if ($stmt->execute()) {
            $success = true;
            $title = $author = $categories = $post_date = $content = '';
        } else {
            $errors[] = "Greška prilikom spremanja vijesti u bazu: " . $conn->error;
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body class="d-flex flex-column">
<main class="flex-shrink-0">
    <?php include 'nav.php'; ?>
    <section class="py-5">
        <div class="container px-5 my-5">
            <h1>CMS - Dodaj vijest</h1>

            <?php if ($success): ?>
                <div class="alert alert-success">Vijest je uspješno spremljena.</div>
            <?php endif; ?>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php foreach ($errors as $error): ?>
                            <li><?= htmlspecialchars($error) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="post" action="" enctype="multipart/form-data" novalidate>
                <div class="mb-3">
                    <label for="title" class="form-label">Naslov</label>
                    <input type="text" id="title" name="title" class="form-control" value="<?= htmlspecialchars($title ?? '') ?>" required>
                </div>

                <div class="mb-3">
                    <label for="author" class="form-label">Autor</label>
                    <input type="text" id="author" name="author" class="form-control" value="<?= htmlspecialchars($author ?? '') ?>" required>
                </div>

                <div class="mb-3">
                    <label for="categories" class="form-label">Kategorije (odvojene zarezom)</label>
                    <input type="text" id="categories" name="categories" class="form-control" value="<?= htmlspecialchars($categories ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label for="post_date" class="form-label">Datum objave</label>
                    <input type="date" id="post_date" name="post_date" class="form-control" value="<?= htmlspecialchars($post_date ?? '') ?>" required>
                </div>

                <div class="mb-3">
                    <label for="image" class="form-label">Slika vijesti (JPEG, PNG, GIF)</label>
                    <input type="file" id="image" name="image" class="form-control" accept="image/jpeg,image/png,image/gif">
                </div>

                <div class="mb-3">
                    <label for="content" class="form-label">Sadržaj vijesti</label>
                    <textarea id="content" name="content" class="form-control" rows="10" required><?= htmlspecialchars($content ?? '') ?></textarea>
                </div>

                <button type="submit" class="btn btn-primary">Spremi vijest</button>
            </form>
        </div>
    </section>
</main>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>

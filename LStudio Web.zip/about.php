<!DOCTYPE html>
<html lang="en">
    <?php include 'head.php'; ?>
    <body class="d-flex flex-column">
        <main class="flex-shrink-0">
            <?php include 'nav.php'; ?>
            <header class="py-5">
                <div class="container px-5">
                    <div class="row justify-content-center">
                        <div class="col-lg-8 col-xxl-6">
                            <div class="text-center my-5">
                                <h1 class="fw-bolder mb-3">Naša misija je omogućiti svakome – pojedincima, kreativcima, udrugama i tvrtkama – jednaku, profesionalnu uslugu.</h1>
                                <p class="lead fw-normal text-muted mb-4">Vjerujemo da svatko ima priču vrijednu snimanja – bilo da se radi o umjetnosti, poslu, hobiju ili osobnom trenutku. Naš cilj je pretvoriti te priče u zvuk i sliku koji ostavljaju dojam, traju i komuniciraju jasno.</p>
                                <a class="btn btn-primary btn-lg" href="#scroll-target">Pročitaj našu priču</a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <section class="py-5 bg-light" id="scroll-target">
                <div class="container px-5 my-5">
                    <div class="row gx-5 align-items-center">
                        <div class="col-lg-6"><img class="img-fluid rounded mb-5 mb-lg-0" src="assets/about/about1.jpg" alt="..." /></div>
                        <div class="col-lg-6">
                            <h2 class="fw-bolder">Naši počeci</h2>
                            <p class="lead fw-normal text-muted mb-0">Sve je započelo s jednostavnom idejom — ispričati priče koje ostavljaju trag. Od prvih projekata, naš cilj je bio stvoriti prostor gdje se kreativnost susreće s profesionalizmom. Strast prema vizualnoj i zvučnoj umjetnosti vodila nas je kroz svaki kadar i svaku notu.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section class="py-5">
                <div class="container px-5 my-5">
                    <div class="row gx-5 align-items-center">
                        <div class="col-lg-6 order-first order-lg-last"><img class="img-fluid rounded mb-5 mb-lg-0" src="assets/about/about2.jpg" alt="..." /></div>
                        <div class="col-lg-6">
                            <h2 class="fw-bolder">Rast i budućnost</h2>
                            <p class="lead fw-normal text-muted mb-0">Kroz godine smo rasli, učili i nadograđivali se. Danas smo spremni za nove izazove — bilo da je riječ o filmu, glazbi, eventima ili digitalnim kampanjama. Gledamo naprijed s jasnom vizijom: stvarati sadržaj koji inspiriše, povezuje i ostavlja trajan dojam.</p>
                        </div>
                    </div>
                </div>
            </section>

            <section class="py-5 bg-light">
                <div class="container px-5 my-5">
                    <div class="text-center">
                        <h2 class="fw-bolder">Naš tim</h2>
                        <p class="lead fw-normal text-muted mb-5">Zadužen za isporuku sadržaja najviše razine kvalitete</p>
                    </div>
                    <div class="row gx-5 row-cols-1 row-cols-sm-2 row-cols-xl-4 justify-content-center">
                        <div class="col mb-5 mb-5 mb-xl-0">
                            <div class="text-center">
                                <img class="img-fluid rounded-circle mb-4 px-4" src="assets/ceo.png" alt="..." />
                                <h5 class="fw-bolder">Lovro Sabljak</h5>
                                <div class="fst-italic text-muted">CEO</div>
                            </div>
                        </div>
                        <div class="col mb-5 mb-5 mb-xl-0">
                            <div class="text-center">
                                <img class="img-fluid rounded-circle mb-4 px-4" src="assets/video.jpg" alt="..." />
                                <h5 class="fw-bolder">Ana Hovat</h5>
                                <div class="fst-italic text-muted">Marketing</div>
                            </div>
                        </div>
                        <div class="col mb-5 mb-5 mb-sm-0">
                            <div class="text-center">
                                <img class="img-fluid rounded-circle mb-4 px-4" src="assets/audio.jpg" alt="..." />
                                <h5 class="fw-bolder">Marko Petrović</h5>
                                <div class="fst-italic text-muted">Menadžer</div>
                            </div>
                        </div>
                        <div class="col mb-5">
                            <div class="text-center">
                                <img class="img-fluid rounded-circle mb-4 px-4" src="assets/publishing.jpg" alt="..." />
                                <h5 class="fw-bolder">Ivan Kovačić </h5>
                                <div class="fst-italic text-muted">Publishing</div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>

        <?php include 'footer.php'; ?>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

        <script src="js/scripts.js"></script>
    </body>
</html>

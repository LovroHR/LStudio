<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    echo "<h2>Primljeni podaci:</h2>";
    echo "<p>Email: " . htmlspecialchars($email) . "</p>";
    echo "<p>Lozinka: " . htmlspecialchars($password) . "</p>";
} else {
    echo "Forma nije ispravno poslana.";
}
?>

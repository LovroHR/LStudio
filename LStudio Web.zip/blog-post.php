<?php
$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška kod povezivanja s bazom: " . $conn->connect_error);
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    die("Neispravan ID vijesti.");
}

$stmt = $conn->prepare("SELECT * FROM news WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$news = $result->fetch_assoc();

if (!$news) {
    die("Vijest nije pronađena.");
}

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
    <?php include 'head.php'; ?>
    <body class="d-flex flex-column">
        <main class="flex-shrink-0">

            <?php include 'nav.php'; ?>

            <section class="py-5">
                <div class="container px-5 my-5">
                    <div class="row gx-5">
                        <div class="col-lg-3">
                            <div class="d-flex align-items-center mt-lg-5 mb-4">
                                <img class="img-fluid rounded-circle" src="https://dummyimage.com/50x50/ced4da/6c757d.jpg" alt="Author" />
                                <div class="ms-3">
                                    <div class="fw-bold"><?= htmlspecialchars($news['author']) ?></div>
                                    <div class="text-muted">
                                        <?php
                                            $categories = array_filter(array_map('trim', explode(',', $news['categories'])));
                                            echo implode(', ', array_map('htmlspecialchars', $categories));
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-9">
                            <article>
                                <header class="mb-4">
                                    <h1 class="fw-bolder mb-1"><?= htmlspecialchars($news['title']) ?></h1>
                                    <div class="text-muted fst-italic mb-2">
                                        <?= date("F j, Y", strtotime($news['post_date'])) ?>
                                    </div>

                                    <?php foreach ($categories as $cat): ?>
                                        <a class="badge bg-secondary text-decoration-none link-light" href="#"><?= htmlspecialchars($cat) ?></a>
                                    <?php endforeach; ?>
                                </header>

                                <?php if (!empty($news['image_path'])): ?>
                                    <figure class="mb-4">
                                        <img class="img-fluid rounded" src="<?= htmlspecialchars($news['image_path']) ?>" alt="News image" />
                                    </figure>
                                <?php endif; ?>

                                <section class="mb-5 fs-5">
                                    <?= nl2br(htmlspecialchars($news['content'])) ?>
                                </section>
                            </article>
                            
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <?php include 'footer.php'; ?>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>

<!DOCTYPE html>
<html lang="en">
    <?php include 'head.php'; ?>
    <body class="d-flex flex-column h-100">
        <main class="flex-shrink-0">
            <?php include 'nav.php'; ?>
            <section class="py-5">
                <div class="container px-5 my-5">
                    <div class="text-center mb-5">
                        <h1 class="fw-bolder">Česta pitanja</h1>
                        <p class="lead fw-normal text-muted mb-0">Mi jedva čekamo da nas kontaktirate, ali prvo pokušajte ovdje pronaći odgovor :)</p>
                    </div>
                    <div class="row gx-5">
                        <div class="col-xl-8">

                            <h2 class="fw-bolder mb-3">Usluge koje nudimo</h2>
                            <div class="accordion mb-5" id="accordionExample">
                                <div class="accordion-item">
                                    <h3 class="accordion-header" id="headingOne"><button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne"><strong>Koje sve usluge nudite?</strong></button></h3>
                                    <div class="accordion-collapse collapse show" id="collapseOne" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            LStudio se specijalizira za profesionalnu izradu promotivnih videa, audio produkciju (poput podcasta, voiceovera i glazbenih produkcija) te fotografiju za različite potrebe – od evenata do proizvoda.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h3 class="accordion-header" id="headingTwo"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo"><strong>Radite li i na terenu?</strong></button></h3>
                                    <div class="accordion-collapse collapse" id="collapseTwo" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            Da, uz studijske uvjete nudimo i terensko snimanje po dogovoru – bilo da se radi o poslovnim prostorima, prirodi ili događanjima.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h3 class="accordion-header" id="headingThree"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree"><strong>Mogu li naručiti samo montažu postojećih materijala?</strong></button></h3>
                                    <div class="accordion-collapse collapse" id="collapseThree" aria-labelledby="headingThree" data-bs-parent="#accordionExample">
                                        <div class="accordion-body">
                                            Naravno! Ako već imate snimljen materijal, rado ćemo odraditi montažu, zvučnu obradu, kolor korekciju i ostalu postprodukciju.
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <h2 class="fw-bolder mb-3">Cijene i plaćanje</h2>
                            <div class="accordion mb-5 mb-xl-0" id="accordionExample2">
                                <div class="accordion-item">
                                    <h3 class="accordion-header" id="headingOne"><button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne2" aria-expanded="true" aria-controls="collapseOne2"><strong>Kako formirate cijene usluga?</strong></button></h3>
                                    <div class="accordion-collapse collapse show" id="collapseOne2" aria-labelledby="headingOne" data-bs-parent="#accordionExample2">
                                        <div class="accordion-body">
                                            Cijena ovisi o trajanju snimanja, vrsti opreme, količini postprodukcije te specifičnim zahtjevima projekta. Svaki klijent dobiva prilagođenu ponudu.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h3 class="accordion-header" id="headingTwo"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo2" aria-expanded="false" aria-controls="collapseTwo2"><strong>Postoji li mogućnost paketa?</strong></button></h3>
                                    <div class="accordion-collapse collapse" id="collapseTwo2" aria-labelledby="headingTwo" data-bs-parent="#accordionExample2">
                                        <div class="accordion-body">
                                            Da! Nudimo povoljne pakete koji uključuju video, foto i audio usluge zajedno – idealno za evente, promocije ili kampanje.
                                        </div>
                                    </div>
                                </div>
                                <div class="accordion-item">
                                    <h3 class="accordion-header" id="headingThree"><button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree2" aria-expanded="false" aria-controls="collapseThree2"><strong>Kako se vrši plaćanje?</strong></button></h3>
                                    <div class="accordion-collapse collapse" id="collapseThree2" aria-labelledby="headingThree" data-bs-parent="#accordionExample2">
                                        <div class="accordion-body">
                                            Plaćanje se vrši putem računa, uz mogućnost avansa ili plaćanja u ratama za veće projekte.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-4">
                            <div class="card border-0 bg-light mt-xl-5">
                                <div class="card-body p-4 py-lg-5">
                                    <div class="d-flex align-items-center justify-content-center">
                                        <div class="text-center">
                                            <div class="h6 fw-bolder">Imate dodatna pitanja?</div>
                                            <p class="text-muted mb-4">
                                                Kontaktirajte nas na
                                                <br />
                                                <a href="#!">support@lstudio.hr</a>
                                            </p>
                                            <!--
                                            <div class="h6 fw-bolder">Zapratite nas</div>
                                            <a class="fs-5 px-2 link-dark" href="#!"><i class="bi-twitter"></i></a>
                                            <a class="fs-5 px-2 link-dark" href="#!"><i class="bi-facebook"></i></a>
                                            <a class="fs-5 px-2 link-dark" href="#!"><i class="bi-linkedin"></i></a>
                                            <a class="fs-5 px-2 link-dark" href="#!"><i class="bi-youtube"></i></a>
                                            !-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>

        <?php include 'footer.php'; ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>

<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body class="d-flex flex-column h-100">
    <main class="flex-shrink-0">
        <?php include 'nav.php'; ?>

        <section class="py-5">
            <div class="container px-5">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card shadow-lg border-0 rounded-3">
                            <div class="card-header bg-primary text-white text-center">
                                <h4 class="mb-0">Registracija korisnika</h4>
                            </div>
                            <div class="card-body p-4">
                                <form action="register_process.php" method="POST">
                                    <div class="row mb-3">
                                        <div class="col">
                                            <label for="name" class="form-label">Ime</label>
                                            <input type="text" class="form-control" name="name" required>
                                        </div>
                                        <div class="col">
                                            <label for="surname" class="form-label">Prezime</label>
                                            <input type="text" class="form-control" name="surname" required>
                                        </div>
                                    </div>
                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email adresa</label>
                                        <input type="email" class="form-control" name="email" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="password" class="form-label">Lozinka</label>
                                        <input type="password" class="form-control" name="password" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="dateOfBirth" class="form-label">Datum rođenja</label>
                                        <input type="date" class="form-control" name="dateOfBirth" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="phone" class="form-label">Broj telefona</label>
                                        <input type="tel" class="form-control" name="phone" required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="address" class="form-label">Adresa</label>
                                        <input type="text" class="form-control" name="address" required>
                                    </div>
                                    <div class="row mb-3">
                                        <div class="col">
                                            <label for="city" class="form-label">Grad</label>
                                            <input type="text" class="form-control" name="city" required>
                                        </div>
                                        <div class="col">
                                            <label for="country" class="form-label">Država</label>
                                            <input type="text" class="form-control" name="country" required>
                                        </div>
                                    </div>
                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-primary btn-lg">Registriraj se</button>
                                    </div>
                                </form>

                                <hr class="my-4">
                                <div class="d-grid mb-3">
                                        <a href="google-login.php" class="btn btn-danger btn-lg">
                                            <i class="bi bi-google"></i> Prijava putem Googlea
                                        </a>
                                    </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>
    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

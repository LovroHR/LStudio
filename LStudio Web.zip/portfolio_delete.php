<?php
session_start();
$conn = new mysqli("localhost", "root", "", "lstudio baza");

if ($conn->connect_error) {
    die("Neuspjelo povezivanje na bazu: " . $conn->connect_error);
}

if (!isset($_GET['id'])) {
    die("ID stavke nije proslijeđen.");
}

$id = (int)$_GET['id'];

$imagesResult = $conn->query("SELECT image_path FROM portfolio_images WHERE portfolio_item_id = $id");

if ($imagesResult) {
    while ($img = $imagesResult->fetch_assoc()) {
        $imagePath = $img['image_path'];
        if (file_exists($imagePath)) {
            unlink($imagePath);  
        }
    }
    $conn->query("DELETE FROM portfolio_images WHERE portfolio_item_id = $id");
}

$conn->query("DELETE FROM portfolio_items WHERE id = $id");

header("Location: portfolio_edit.php"); 
exit;
?>

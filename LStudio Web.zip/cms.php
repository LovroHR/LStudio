<?php
// Povezivanje s bazom
$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška kod povezivanja s bazom: " . $conn->connect_error);
}

// Brisanje vijesti ako je traženo
if (isset($_GET['delete_id'])) {
    $delete_id = (int)$_GET['delete_id'];
    // Prvo možeš dodati sigurnosnu provjeru (npr. potvrdu)
    $stmt = $conn->prepare("DELETE FROM news WHERE id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->close();
    header("Location: cms.php"); // refresh stranice nakon brisanja
    exit();
}

// Dohvati sve vijesti
$sql = "SELECT id, title, post_date, author FROM news ORDER BY post_date DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
    <?php include 'head.php'; ?>
<body class="d-flex flex-column">
    <main class="flex-shrink-0">
        <!-- Navigation-->
        <?php include 'nav.php'; ?>

        <section class="py-5">
            <div class="container px-5">
                <h1 class="mb-4">Upravljanje vijestima</h1>

                <?php if ($result && $result->num_rows > 0): ?>
                    <table class="table table-bordered table-striped align-middle">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Naslov</th>
                                <th>Datum</th>
                                <th>Autor</th>
                                <th>Akcije</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($news = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= $news['id'] ?></td>
                                    <td><?= htmlspecialchars($news['title']) ?></td>
                                    <td><?= date("d.m.Y", strtotime($news['post_date'])) ?></td>
                                    <td><?= htmlspecialchars($news['author']) ?></td>
                                    <td>
                                        <a href="cms_edit.php?id=<?= $news['id'] ?>" class="btn btn-sm btn-primary me-2">Uredi</a>
                                        <a href="cms.php?delete_id=<?= $news['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Jeste li sigurni da želite obrisati ovu vijest?');">Obriši</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>Nema nijedne vijesti u bazi.</p>
                <?php endif; ?>

                <a href="cms_add.php" class="btn btn-success">Dodaj novu vijest</a>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <?php include 'footer.php'; ?>

    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
</body>
</html>

<?php
$conn->close();
?>

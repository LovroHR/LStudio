<?php
session_start();
$conn = new mysqli("localhost", "root", "", "lstudio baza");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);

    $conn->query("INSERT INTO portfolio_items (title, description) VALUES ('$title', '$description')");
    $itemId = $conn->insert_id;

    foreach ($_FILES['images']['tmp_name'] as $index => $tmpPath) {
        if ($_FILES['images']['error'][$index] === 0) {
            $imageName = time() . '_' . basename($_FILES['images']['name'][$index]);
            move_uploaded_file($tmpPath, "uploads/portfolio/$imageName");
            $conn->query("INSERT INTO portfolio_images (portfolio_item_id, image_path) VALUES ($itemId, 'uploads/portfolio/$imageName')");
        }
    }

    header("Location: portfolio_edit.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body class="d-flex flex-column min-vh-100">
<main class="flex-grow-1">
    <?php include 'nav.php'; ?>

    <div class="container py-5">
        <h1>Dodaj novu stavku</h1>
        <form method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="title" class="form-label">Naslov</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Opis</label>
                <textarea name="description" class="form-control" rows="4"></textarea>
            </div>
            <div class="mb-3">
                <label for="images" class="form-label">Fotografije</label>
                <input type="file" name="images[]" class="form-control" multiple accept="image/*">
            </div>
            <button type="submit" class="btn btn-success">Spremi</button>
        </form>
    </div>
</main>

<?php include 'footer.php'; ?>
</body>
</html>

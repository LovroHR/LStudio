<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container px-5">
        <a class="navbar-brand" href="index.php">
            <b><span class="text-primary">LS</span></b>tudio
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" 
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="index.php">Početna</a></li>
                <li class="nav-item"><a class="nav-link" href="about.php">O nama</a></li>
                <li class="nav-item"><a class="nav-link" href="contact.php">Kontakt</a></li>
                <li class="nav-item"><a class="nav-link" href="faq.php">FAQ</a></li>
                <li class="nav-item"><a class="nav-link" href="blog-home.php">Vijesti</a></li>
                <li class="nav-item"><a class="nav-link" href="portfolio-overview.php">Portfolio</a></li>
                <?php if (isset($_SESSION['user'])): ?>
                    <?php if (isset($_SESSION['user']['role']) && $_SESSION['user']['role'] === 'admin'): ?>
                        <li class="nav-item"><a class="nav-link" href="admin_dash.php">Admin profil</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="user.php">Moj profil</a></li>
                    <?php endif; ?>
                    <li class="nav-item"><a class="nav-link" href="logout.php">Odjava</a></li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="login.php">Prijava</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

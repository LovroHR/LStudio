<?php
session_start();

if (!isset($_SESSION['user']['email'])) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$email = $_SESSION['user']['email'];

$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    die("Korisnik nije pronađen u bazi.");
}

$user = $result->fetch_assoc();

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body class="d-flex flex-column h-100">
    <main class="flex-shrink-0">
        <?php include 'nav.php'; ?>

        <section class="py-5">
            <div class="container px-5">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <h2 class="mb-4 text-center">Uredi profil</h2>
                        <div class="card shadow-lg border-0 rounded-3">
                            <div class="card-body p-4">
                                <form action="user_edit_process.php" method="POST">
                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="name" class="form-label">Ime</label>
                                            <input type="text" id="name" name="name" class="form-control" required
                                                value="<?php echo htmlspecialchars($user['name']); ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="surname" class="form-label">Prezime</label>
                                            <input type="text" id="surname" name="surname" class="form-control" required
                                                value="<?php echo htmlspecialchars($user['surname']); ?>">
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email adresa</label>
                                        <input type="email" id="email" name="email" class="form-control" required
                                            value="<?php echo htmlspecialchars($user['email']); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label for="password" class="form-label">Nova lozinka (ostavi prazno za nepromjenu)</label>
                                        <input type="password" id="password" name="password" class="form-control" placeholder="Unesi novu lozinku">
                                    </div>

                                    <div class="mb-3">
                                        <label for="dateOfBirth" class="form-label">Datum rođenja</label>
                                        <input type="date" id="dateOfBirth" name="dateOfBirth" class="form-control" required
                                            value="<?php echo htmlspecialchars($user['dateOfBirth']); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label for="phone" class="form-label">Telefon</label>
                                        <input type="text" id="phone" name="phone" class="form-control"
                                            value="<?php echo htmlspecialchars($user['phone']); ?>">
                                    </div>

                                    <div class="mb-3">
                                        <label for="address" class="form-label">Adresa</label>
                                        <input type="text" id="address" name="address" class="form-control"
                                            value="<?php echo htmlspecialchars($user['address']); ?>">
                                    </div>

                                    <div class="row mb-3">
                                        <div class="col-md-6">
                                            <label for="city" class="form-label">Grad</label>
                                            <input type="text" id="city" name="city" class="form-control"
                                                value="<?php echo htmlspecialchars($user['city']); ?>">
                                        </div>
                                        <div class="col-md-6">
                                            <label for="country" class="form-label">Država</label>
                                            <input type="text" id="country" name="country" class="form-control"
                                                value="<?php echo htmlspecialchars($user['country']); ?>">
                                        </div>
                                    </div>

                                    <div class="d-grid">
                                        <button type="submit" class="btn btn-primary btn-lg">Spremi promjene</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </main>

    <?php include 'footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/scripts.js"></script>
</body>
</html>

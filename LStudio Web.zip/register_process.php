<?php
$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$name = $_POST['name'];
$surname = $_POST['surname'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$dateOfBirth = $_POST['dateOfBirth'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$city = $_POST['city'];
$country = $_POST['country'];
$role = 'user';

$checkSql = "SELECT id FROM users WHERE email = ?";
$checkStmt = $conn->prepare($checkSql);
$checkStmt->bind_param("s", $email);
$checkStmt->execute();
$checkStmt->store_result();

if ($checkStmt->num_rows > 0) {
    echo "Korisnik s ovim emailom već postoji. <a href='register.php'>Pokušaj ponovo</a>";
    $checkStmt->close();
    $conn->close();
    exit;
}
$checkStmt->close();

$sql = "INSERT INTO users (name, surname, email, password, dateOfBirth, phone, address, city, country, role)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssssssss", $name, $surname, $email, $password, $dateOfBirth, $phone, $address, $city, $country, $role);

if ($stmt->execute()) {
    echo "Registracija uspješna! <a href='login.php'>Prijavi se</a>";
} else {
    echo "Greška prilikom registracije: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>

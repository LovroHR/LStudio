<?php
session_start();

if (!isset($_SESSION['user']['email'])) {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$email = $_SESSION['user']['email'];

$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    die("Korisnik nije pronađen.");
}

$user = $result->fetch_assoc();
$userId = $user['ID'];

$missingData = false;
if (empty($user['phone']) || empty($user['address']) || empty($user['dateOfBirth'])) {
    $missingData = true;
}

$profileImage = 'https://via.placeholder.com/100';
$imgQuery = $conn->prepare("SELECT path FROM profile_picture WHERE user_id = ?");
$imgQuery->bind_param("i", $userId);
$imgQuery->execute();
$imgResult = $imgQuery->get_result();
if ($imgResult->num_rows > 0) {
    $imgRow = $imgResult->fetch_assoc();
    $profileImage = $imgRow['path'];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_image'])) {
    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $fileTmp = $_FILES['profile_image']['tmp_name'];
    $fileName = basename($_FILES['profile_image']['name']);
    $targetPath = $uploadDir . time() . '_' . $fileName;

    if (move_uploaded_file($fileTmp, $targetPath)) {
        $fullPath = $targetPath;
        $stmt = $conn->prepare("INSERT INTO profile_picture (user_id, path) VALUES (?, ?) ON DUPLICATE KEY UPDATE path = ?");
        $stmt->bind_param("iss", $userId, $fullPath, $fullPath);
        $stmt->execute();
        header("Location: user.php");
        exit;
    }
}

$sqlProjects = "SELECT * FROM projects WHERE user_id = ? ORDER BY created_at DESC";
$stmtProjects = $conn->prepare($sqlProjects);
$stmtProjects->bind_param("i", $userId);
$stmtProjects->execute();
$projectsResult = $stmtProjects->get_result();

$activeProjects = [];
$completedProjects = [];

while ($project = $projectsResult->fetch_assoc()) {
    if ($project['status'] === 'active') {
        $activeProjects[] = $project;
    } else {
        $completedProjects[] = $project;
    }
}

$stmt->close();
$stmtProjects->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body class="d-flex flex-column h-100">
<main class="flex-shrink-0">
    <?php include 'nav.php'; ?>

    <section class="py-5 bg-light">
        <div class="container px-5">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <!-- Profil -->
                    <div class="card border-0 shadow rounded-3 mb-4">
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center mb-4">
                                <form method="POST" enctype="multipart/form-data" id="uploadForm">
                                    <label for="profileImageInput">
                                        <img src="<?= htmlspecialchars($profileImage) ?>" class="rounded-circle me-3" alt="Profilna slika" style="width: 100px; height: 100px; object-fit: cover; cursor: pointer;">
                                    </label>
                                    <input type="file" id="profileImageInput" name="profile_image" accept="image/*" style="display: none;" onchange="document.getElementById('uploadForm').submit();">
                                </form>
                                <div>
                                    <h4 class="mb-0"><?= htmlspecialchars($user['name'] . ' ' . $user['surname']) ?></h4>
                                    <p class="text-muted mb-0"><?= htmlspecialchars($user['email']) ?></p>
                                </div>
                            </div>
                            <hr>
                            <h5 class="mb-3">Osobni podaci</h5>
                            <ul class="list-group list-group-flush mb-4">
                                <li class="list-group-item"><strong>Telefon:</strong> <?= htmlspecialchars($user['phone']) ?></li>
                                <li class="list-group-item"><strong>Adresa:</strong> <?= htmlspecialchars($user['address']) ?></li>
                                <li class="list-group-item"><strong>Datum rođenja:</strong> <?= htmlspecialchars($user['dateOfBirth']) ?></li>
                            </ul>
                            <div class="d-flex justify-content-between">
                                <a href="user_edit.php" class="btn btn-outline-primary">
                                    Uredi profil
                                    <?php if ($missingData): ?>
                                        <span title="Nedostaju podaci u profilu" style="color: red; font-weight: bold; margin-left: 5px;">&#x26A0;</span>
                                    <?php endif; ?>
                                </a>
                                <a href="logout.php" class="btn btn-danger">Odjava</a>
                            </div>
                        </div>
                    </div>

                    <div class="card border-0 shadow rounded-3 mt-4">
                        <div class="card-body p-4">
                            <h5 class="mb-3">Moji projekti</h5>
                            <div class="accordion" id="projektiAccordion">

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingAktualni">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#aktualni" aria-expanded="true" aria-controls="aktualni">
                                            Aktivni projekti
                                        </button>
                                    </h2>
                                    <div id="aktualni" class="accordion-collapse collapse show" aria-labelledby="headingAktualni" data-bs-parent="#projektiAccordion">
                                        <div class="accordion-body">
                                            <?php if (count($activeProjects) > 0): ?>
                                                <ul class="list-group">
                                                    <?php foreach ($activeProjects as $project): ?>
                                                        <li class="list-group-item">
                                                            🔴 <strong><?= htmlspecialchars($project['title']) ?></strong><br>
                                                            <small>Dodano: <?= date("d. F Y", strtotime($project['created_at'])) ?></small>
                                                            <p class="mb-2 text-muted small"><?= htmlspecialchars($project['description']) ?></p>
                                                        </li>
                                                    <?php endforeach; ?>
                                                </ul>
                                            <?php else: ?>
                                                <p>Nema aktivnih projekata.</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item">
                                    <h2 class="accordion-header" id="headingGotovi">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#gotovi" aria-expanded="false" aria-controls="gotovi">
                                            Zavrseni projekti
                                        </button>
                                    </h2>
                                    <div id="gotovi" class="accordion-collapse collapse" aria-labelledby="headingGotovi" data-bs-parent="#projektiAccordion">
                                        <div class="accordion-body">
                                            <?php if (count($completedProjects) > 0): ?>
                                                <ul class="list-group">
                                                    <?php foreach ($completedProjects as $project): ?>
                                                        <li class="list-group-item">
                                                            🟢 <strong><?= htmlspecialchars($project['title']) ?></strong><br>
                                                            <small>Dodano: <?= date("d. F Y", strtotime($project['created_at'])) ?></small>
                                                            <p class="mb-2 text-muted small"><?= htmlspecialchars($project['description']) ?></p>
                                                        </li>
                                                    <?php endforeach; ?>
                                                </ul>
                                            <?php else: ?>
                                                <p>Nema završenih projekata.</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

</main>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>

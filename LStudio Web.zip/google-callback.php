<?php
session_start();
require_once __DIR__ . '/vendor/autoload.php';

$client = new Google_Client();
$stack = \GuzzleHttp\HandlerStack::create();
$guzzleClient = new \GuzzleHttp\Client(['handler' => $stack, 'http_errors' => false]);
$client->setHttpClient($guzzleClient);

$client->setClientId('762944395886-vm6nhkj6gfqipc1b531shvfkm69onjoh.apps.googleusercontent.com');
$client->setClientSecret('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');
$client->setRedirectUri('http://localhost/bootstrap/google-callback.php');
$client->addScope('email');
$client->addScope('profile');

if (isset($_GET['code'])) {
    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);

    if (isset($token['error'])) {
        echo "Greška pri dohvaćanju tokena: " . htmlspecialchars($token['error']);
        exit;
    }

    $client->setAccessToken($token);

    $oauth2 = new Google_Service_Oauth2($client);
    $googleUser = $oauth2->userinfo->get();

    $googleId = $googleUser->id;
    $email = $googleUser->email;
    $name = $googleUser->givenName;
    $surname = $googleUser->familyName;
    $role = 'user';

    $conn = new mysqli("localhost", "root", "", "lstudio baza");
    if ($conn->connect_error) {
        die("Greška kod spajanja na bazu: " . $conn->connect_error);
    }

    $stmt = $conn->prepare("SELECT * FROM users WHERE google_id = ?");
    $stmt->bind_param("s", $googleId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        $checkEmail = $conn->prepare("SELECT * FROM users WHERE email = ? AND google_id IS NULL");
        $checkEmail->bind_param("s", $email);
        $checkEmail->execute();
        $result = $checkEmail->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $userId = $user['id'];

            $update = $conn->prepare("UPDATE users SET google_id = ? WHERE id = ?");
            $update->bind_param("si", $googleId, $userId);
            $update->execute();
            $update->close();
        } else {

            $insert = $conn->prepare("INSERT INTO users (google_id, email, name, surname, role) VALUES (?, ?, ?, ?, ?)");
            $insert->bind_param("sssss", $googleId, $email, $name, $surname, $role);
            $insert->execute();
            $userId = $insert->insert_id;
            $insert->close();

            $select = $conn->prepare("SELECT * FROM users WHERE id = ?");
            $select->bind_param("i", $userId);
            $select->execute();
            $result = $select->get_result();
            $user = $result->fetch_assoc();
            $select->close();
        }

        $checkEmail->close();
    }

    $stmt->close();
    $conn->close();

    $_SESSION['user'] = [
        'name' => $user['name'],
        'surname' => $user['surname'],
        'email' => $user['email'],
        'dateOfBirth' => $user['dateOfBirth'] ?? '',
        'phone' => $user['phone'] ?? '',
        'address' => $user['address'] ?? '',
        'city' => $user['city'] ?? '',
        'country' => $user['country'] ?? '',
        'role' => $user['role']
    ];

    if ($user['role'] === 'admin') {
        header("Location: admin_dash.php");
    } else {
        header("Location: user.php");
    }
    exit;
} else {
    echo "Nema auth koda.";
}

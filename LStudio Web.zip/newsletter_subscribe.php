<?php
session_start();

$api_key = trim(file_get_contents('mailer_api_token.txt'));

function addSubscriberToMailerLite($email, $api_key) {
    $url = 'https://api.mailerlite.com/api/v2/subscribers';
    $data = json_encode([
        'email' => $email,
        'resubscribe' => true
    ]);

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'X-MailerLite-ApiKey: ' . $api_key
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_exec($ch);
    $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return $httpcode === 200 || $httpcode === 201;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['newsletter_email'])) {
    $email = trim($_POST['newsletter_email']);
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        if (addSubscriberToMailerLite($email, $api_key)) {
            $_SESSION['newsletterMessage'] = '<div class="alert alert-success mt-2">Uspješno ste se prijavili na newsletter.</div>';
        } else {
            $_SESSION['newsletterMessage'] = '<div class="alert alert-danger mt-2">Došlo je do pogreške prilikom prijave na newsletter.</div>';
        }
    } else {
        $_SESSION['newsletterMessage'] = '<div class="alert alert-warning mt-2">Unesite ispravnu email adresu.</div>';
    }

    header('Location: index.php');
    exit;
}
?>

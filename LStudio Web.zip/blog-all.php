<?php
$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška kod povezivanja s bazom: " . $conn->connect_error);
}

$newsPerPage = 8;

$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;

$offset = ($page - 1) * $newsPerPage;

$totalNewsResult = $conn->query("SELECT COUNT(*) AS total FROM news");
$totalNewsRow = $totalNewsResult->fetch_assoc();
$totalNews = $totalNewsRow['total'];

$totalPages = ceil($totalNews / $newsPerPage);

$sql = "SELECT * FROM news ORDER BY post_date DESC LIMIT $newsPerPage OFFSET $offset";
$result = $conn->query($sql);
$newsList = [];
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $newsList[] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<?php include 'head.php'; ?>
<body class="d-flex flex-column">
<main class="flex-shrink-0">
    <?php include 'nav.php'; ?>
    <section class="py-5">
        <div class="container px-5">
            <h1 class="fw-bolder fs-5 mb-4">Arhiva vijesti</h1>
            <?php if (count($newsList) > 0): ?>
                <?php foreach ($newsList as $news): ?>
                    <div class="card mb-4 shadow border-0">
                        <div class="row g-0">
                            <div class="col-md-4">
                                <?php if (!empty($news['image_path'])): ?>
                                    <img src="<?= htmlspecialchars($news['image_path']) ?>" class="img-fluid h-100 object-fit-cover" alt="News image">
                                <?php else: ?>
                                    <img src="https://dummyimage.com/600x400/ced4da/6c757d" class="img-fluid h-100 object-fit-cover" alt="Default image">
                                <?php endif; ?>
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <div class="small text-muted mb-1">
                                        <?= date("F j, Y", strtotime($news['post_date'])) ?>
                                    </div>
                                    <h5 class="card-title">
                                        <a class="text-decoration-none link-dark" href="blog-post.php?id=<?= $news['id'] ?>">
                                            <?= htmlspecialchars($news['title']) ?>
                                        </a>
                                    </h5>
                                    <p class="card-text">
                                        <?= nl2br(htmlspecialchars(substr($news['content'], 0, 200))) ?>...
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>

                <nav>
                    <ul class="pagination justify-content-center">
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?= ($i === $page) ? 'active' : '' ?>">
                                <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>

            <?php else: ?>
                <p>No news found.</p>
            <?php endif; ?>
        </div>
    </section>
</main>
<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>
<?php $conn->close(); ?>

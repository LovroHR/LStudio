<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$search = isset($_GET['search']) ? $conn->real_escape_string(trim($_GET['search'])) : '';

$usersSql = "SELECT id, name, surname, email FROM users WHERE role = 'user'";

if (!empty($search)) {
    $usersSql .= " AND (name LIKE '%$search%' OR surname LIKE '%$search%' OR email LIKE '%$search%')";
}

$usersSql .= " ORDER BY surname ASC, name ASC";

$usersResult = $conn->query($usersSql);
?>

<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body class="d-flex flex-column h-100">
<main class="flex-shrink-0">
    <?php include 'nav.php'; ?>

    <section class="py-5">
        <div class="container px-5">
            <h1 class="mb-4">Admin panel - korisnici i projekti</h1>

            <a href="cms.php" class="btn btn-success mb-4">Otvori CMS</a>

            <a href="portfolio_edit.php" class="btn btn-success mb-4">Uredi portfolio</a>

            <form class="mb-4" method="get" action="">
                <div class="input-group">
                    <input type="text" class="form-control" name="search" placeholder="Pretraži korisnike..." value="<?= htmlspecialchars($search) ?>">
                    <button class="btn btn-primary" type="submit">Pretraži</button>
                    <?php if (!empty($search)): ?>
                        <a href="admin_dash.php" class="btn btn-outline-secondary">Poništi</a>
                    <?php endif; ?>
                </div>
            </form>

            <?php if ($usersResult->num_rows > 0): ?>
                <div class="accordion" id="usersAccordion">
                    <?php while ($user = $usersResult->fetch_assoc()):
                        $userId = $user['id'];

                        $picResult = $conn->query("SELECT path FROM profile_picture WHERE user_id = $userId LIMIT 1");
                        if ($picResult && $picResult->num_rows > 0) {
                            $picRow = $picResult->fetch_assoc();
                            $profilePicPath = $picRow['path'];
                        } else {
                            $profilePicPath = 'uploads/default.png'; // defaultna slika
                        }

                        $activeProjects = $conn->query("SELECT * FROM projects WHERE user_id = $userId AND status = 'active'");
                        $completedProjects = $conn->query("SELECT * FROM projects WHERE user_id = $userId AND status = 'completed'");
                    ?>
                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingUser<?= $userId ?>">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#collapseUser<?= $userId ?>" aria-expanded="false"
                                        aria-controls="collapseUser<?= $userId ?>">
                                    <img src="<?= htmlspecialchars($profilePicPath) ?>" alt="Profilna slika"
                                         style="width:40px; height:40px; object-fit: cover; border-radius: 50%; margin-right: 10px;">
                                    <?= htmlspecialchars($user['surname'] . ' ' . $user['name']) ?> (<?= htmlspecialchars($user['email']) ?>)
                                </button>
                            </h2>
                            <div id="collapseUser<?= $userId ?>" class="accordion-collapse collapse"
                                 aria-labelledby="headingUser<?= $userId ?>" data-bs-parent="#usersAccordion">
                                <div class="accordion-body">
                                    <h5>Aktivni projekti</h5>
                                    <?php if ($activeProjects->num_rows > 0): ?>
                                        <ul>
                                            <?php while ($project = $activeProjects->fetch_assoc()): ?>
                                                <li class="mb-2">
                                                    <strong><?= htmlspecialchars($project['title']) ?></strong><br>
                                                    <?= htmlspecialchars($project['description']) ?><br>
                                                    <small>Stvoren: <?= htmlspecialchars($project['created_at']) ?></small><br>
                                                    <a href="admin_update_project.php?project_id=<?= $project['id'] ?>" class="btn btn-sm btn-warning mt-1">Uredi</a>
                                                    <a href="admin_delete_project.php?project_id=<?= $project['id'] ?>" class="btn btn-sm btn-danger mt-1" onclick="return confirm('Jeste li sigurni da želite obrisati ovaj projekt?');">Obriši</a>
                                                </li>
                                            <?php endwhile; ?>
                                        </ul>
                                    <?php else: ?>
                                        <p>Nema aktivnih projekata.</p>
                                    <?php endif; ?>

                                    <h5 class="mt-4">Završeni projekti</h5>
                                    <?php if ($completedProjects->num_rows > 0): ?>
                                        <ul>
                                            <?php while ($project = $completedProjects->fetch_assoc()): ?>
                                                <li class="mb-2">
                                                    <strong><?= htmlspecialchars($project['title']) ?></strong><br>
                                                    <?= htmlspecialchars($project['description']) ?><br>
                                                    <small>Završen: <?= htmlspecialchars($project['created_at']) ?></small><br>
                                                    <a href="admin_update_project.php?project_id=<?= $project['id'] ?>" class="btn btn-sm btn-warning mt-1">Uredi</a>
                                                    <a href="admin_delete_project.php?project_id=<?= $project['id'] ?>" class="btn btn-sm btn-danger mt-1" onclick="return confirm('Jeste li sigurni da želite obrisati ovaj projekt?');">Obriši</a>
                                                </li>
                                            <?php endwhile; ?>
                                        </ul>
                                    <?php else: ?>
                                        <p>Nema završenih projekata.</p>
                                    <?php endif; ?>

                                    <h6 class="mt-3">Dodaj novi projekt</h6>
                                    <a class="btn btn-sm btn-primary" href="admin_add_project.php?user_id=<?= $userId ?>">Dodaj projekt</a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php else: ?>
                <p>Nema korisnika koji odgovaraju pretrazi.</p>
            <?php endif; ?>
        </div>
    </section>
</main>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/scripts.js"></script>
</body>
</html>

<?php $conn->close(); ?>

-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 01, 2025 at 06:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lstudio baza`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(100) NOT NULL,
  `categories` varchar(255) DEFAULT NULL,
  `post_date` date NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `author`, `categories`, `post_date`, `image_path`, `content`, `created_at`) VALUES
(11, 'LSTUDIO otvara novu poslovnicu u Zagrebu!', 'Lovro Sabljak', 'poslovnica, otvorenje', '2025-03-21', 'uploads/img_683c766b689087.23462484.jpg', 'Uzbuđeni smo što možemo najaviti otvaranje nove poslovnice LSTUDIO u samom srcu Zagreba! Nakon dugogodišnjeg uspjeha i rasta, odlučili smo proširiti svoje poslovanje kako bismo bili još bliže našim klijentima.\r\n\r\nNova poslovnica smještena je na atraktivnoj lokaciji i opremljena najsuvremenijom tehnologijom kako bismo mogli pružiti vrhunsku uslugu iz područja dizajna, fotografije i multimedije.\r\n\r\nPozivamo sve postojeće i buduće klijente da nas posjete te iskoriste promotivne pogodnosti povodom otvorenja!\r\n\r\n? Otvorenje: 15. lipnja 2025.\r\n? Lokacija: Masarykova 10, Zagreb\r\n\r\nVidimo se!', '2025-06-01 15:48:43'),
(12, 'Suradnja s Grip Filmom na snimanju novog filmskog projekta', 'Ivica Ivek', 'snimanje, oprema, suradnja, grip film', '2024-06-09', 'uploads/img_683c76c0f206d5.99078789.jpg', 'LSTUDIO s ponosom objavljuje uspješnu suradnju s renomiranom firmom Grip Film, specijaliziranom za iznajmljivanje profesionalne filmske opreme. Tijekom posljednjeg snimanja kratkometražnog filma u produkciji LSTUDIO-a, koristili smo njihovu opremu za rasvjetu, grip i kameru, što je značajno doprinijelo vizualnoj kvaliteti projekta.\r\n\r\nTim iz Grip Filma pokazao se kao izuzetno profesionalan i tehnički potkovan partner, pružajući podršku na setu i pomažući u postavljanju ključne opreme za kompleksne kadrove. Zahvaljujući toj suradnji, snimanje je proteklo bez zastoja i u skladu s planiranim rasporedom.\r\n\r\nVeselimo se budućim zajedničkim projektima i zahvaljujemo Grip Filmu na povjerenju i vrhunskoj podršci.', '2025-06-01 15:50:24'),
(13, 'Počelo snimanje filma \"E moj Saša\"', 'FKVKZ', 'snimanje, film', '2024-04-01', 'uploads/img_683c7768f13495.45823455.jpg', 'Započelo je snimanje dugometražnog igranog filma „E moj Saša”, najnovijeg projekta produkcijske kuće LStudio, koji obećava dirljivu priču o odrastanju, obiteljskim odnosima i potrazi za identitetom u suvremenoj Hrvatskoj.\r\n\r\nFilm prati mladog Sašu kroz niz emotivnih izazova dok pokušava pronaći svoje mjesto u svijetu prepunom očekivanja, naslijeđenih trauma i osobnih odluka. Režiju potpisuje nagrađivani redatelj Marko L. Petrović, dok glavne uloge tumače Ivan Čuić, Dora Perković, i legendarni Zoran Vrdoljak.\r\n\r\nSnimanje se odvija na lokacijama u Zagrebu, Karlovcu i Gorskom kotaru te se očekuje da će trajati do kraja kolovoza. Produkcijski tim koristi naprednu tehniku snimanja, uključujući kamere visoke rezolucije i filmsku rasvjetu, a u tehničkoj realizaciji surađujemo s renomiranom firmom Grip Film, koja osigurava profesionalnu opremu i podršku na setu.\r\n\r\n    „Ovo je jedan od onih filmova koji se ne zaboravljaju lako. Autentičan je, iskren i progovara o stvarima koje su svima bliske, a rijetko se iskreno prikazuju na ekranu,” rekao je redatelj Petrović na početku snimanja.\r\n\r\nPremijera filma očekuje se u prvoj polovici 2026. godine, a već sada izaziva interes domaće publike i kritike.', '2025-06-01 15:53:12'),
(14, 'LStudio dovršio postprodukciju dokumentarca \"Zidovi tišine\"', 'Pero Perić', 'post produkcija', '2022-08-30', 'uploads/img_683c77d3144f49.44649222.jpg', 'Nakon mjeseci intenzivnog rada, LStudio je uspješno završio postprodukciju dokumentarnog filma \"Zidovi tišine\", koji istražuje živote ljudi u izoliranim ruralnim krajevima Hrvatske. Redateljica Ana Radić vodi gledatelje kroz duboko emotivne priče osoba koje svakodnevno žive s osjećajem usamljenosti, ali i s nevjerojatnom snagom duha.\r\n\r\nFilm je realiziran u suradnji s HRT-om, a posebnu pažnju posvećena je autentičnom zvuku i atmosferi – svaka scena pažljivo je oblikovana kako bi dočarala stvarni osjećaj prostora. Premijera je zakazana za jesen 2022.', '2025-06-01 15:54:59'),
(15, 'LStudio u Cannesu – međunarodna suradnja na vidiku', 'Lana Lanić', 'film, suradnja', '2023-02-04', 'uploads/img_683c7810b88ac4.38669536.jpg', 'Tijekom ovogodišnjeg Filmskog festivala u Cannesu, ekipa LStudio predstavila je nekoliko novih projekata i održala niz sastanaka s europskim i američkim producentima. Najviše interesa izazvao je projekt \"Kao kiša u lipnju\", romantična drama smještena u Istru.\r\n\r\nLStudio je tako zakoračio prema međunarodnoj koprodukciji, a u planu je suradnja s belgijskim i francuskim studijima. \"Otvaranje prema inozemstvu prirodan je korak za nas,\" rekao je direktor studija Dario Lukić.', '2025-06-01 15:56:00'),
(16, 'Radionica snimanja vokala u LStudiju', 'Lovro Sabljak', 'zvuk, studio, snimanje, vokal, radionica', '2024-07-06', 'uploads/img_683c7843ae38d4.05763067.jpg', 'U lipnju je u LStudiju održana radionica snimanja vokala za početnike i napredne korisnike. Sudionici su učili pravilnu tehniku snimanja, pozicioniranje mikrofona i rad s akustikom prostora.\r\nVoditelj radionice bio je naš glazbeni producent Ivan Horvat, a svi sudionici su imali priliku isprobati profesionalnu opremu i snimiti demo zapise.', '2025-06-01 15:56:51'),
(17, 'Novi glazbeni album u pripremi uz pomoć LStudija', 'Nino Ninić', 'glazba, zvuk, pjesma, album', '2025-05-12', 'uploads/img_683c7872412ea2.07598806.jpg', 'LStudio je ponosan na početak suradnje s mladim talentom Ninom Goranom Tosenbergerom koji priprema svoj prvi studijski album.\r\nProjekat uključuje snimanje, miks i mastering u našem studiju uz podršku profesionalnih zvučnih inženjera i glazbenih producenata.\r\nOčekuje se da će album donijeti svježi zvuk i inovativne glazbene pristupe.', '2025-06-01 15:57:38'),
(18, '\"Noć u tišini\" osvojila nagradu za najbolju kameru', 'Marko Markić', 'nagrada, film', '2025-01-01', 'uploads/img_683c78ac550f89.36845695.jpg', 'Na filmskom festivalu Zagreb Film Week, film \"Noć u tišini\", u produkciji LStudija, nagrađen je za najbolju kameru. Direktor fotografije Matija Erceg pohvaljen je zbog izuzetnog osjećaja za kompoziciju i korištenje svjetla u noćnim scenama.\r\n\r\nFilm tematizira odnos dvoje stranaca koji se susreću tijekom jedne kišne noći u Splitu. Kritika ga je opisala kao \"vizualno poetičnu studiju tišine i tuge.\"', '2025-06-01 15:58:36'),
(19, 'Kratki film \"Prašina\" u konkurenciji festivala u Sarajevu', 'Ivana Sabljić', 'film, konkurencija, sarajevo', '2025-01-30', 'uploads/img_683c78f8eb4690.51612441.jpg', 'Kratkometražni film \"Prašina\", redateljice Ivane Sabljić, ušao je u službenu konkurenciju Sarajevo Film Festivala 2025. Film prati priču starice koja nakon smrti muža otkriva dugo čuvanu tajnu u tavanu svoje kuće.\r\n\r\n\"Radili smo ovaj film s ljubavlju i bez pretjeranih očekivanja, zato nas je ova vijest zatekla i oduševila,\" rekla je redateljica.', '2025-06-01 15:59:52');

-- --------------------------------------------------------

--
-- Table structure for table `newsletter_subscribers`
--

CREATE TABLE `newsletter_subscribers` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subscribed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `newsletter_subscribers`
--

INSERT INTO `newsletter_subscribers` (`id`, `email`, `subscribed_at`) VALUES
(1, 'sablja04@gmail.com', '2025-06-01 14:04:15');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio_images`
--

CREATE TABLE `portfolio_images` (
  `id` int(11) NOT NULL,
  `portfolio_item_id` int(11) NOT NULL,
  `image_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `portfolio_images`
--

INSERT INTO `portfolio_images` (`id`, `portfolio_item_id`, `image_path`) VALUES
(36, 23, 'uploads/portfolio/1748793695_photo_2025-05-31_13-03-24.jpg'),
(37, 23, 'uploads/portfolio/1748793695_photo_2025-05-31_13-03-23.jpg'),
(38, 24, 'uploads/portfolio/1748793802_sasa thumbnail.jpg'),
(39, 25, 'uploads/portfolio/1748793863_photo_2025-05-31_12-47-17.jpg'),
(40, 25, 'uploads/portfolio/1748793863_photo_2025-05-31_12-47-14.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `portfolio_items`
--

CREATE TABLE `portfolio_items` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `portfolio_items`
--

INSERT INTO `portfolio_items` (`id`, `title`, `description`, `created_at`) VALUES
(23, 'Snimanje opremom GRIP FILM', 'Ponosni smo na našu suradnju sa GRIP FILM!', '2025-06-01 16:01:35'),
(24, 'E moj Saša - FILM', 'Snimljen film E moj Saša!', '2025-06-01 16:03:22'),
(25, 'Snimanje albuma benda TiMater', 'Ponosni na prvi album benda TiMater!', '2025-06-01 16:04:23');

-- --------------------------------------------------------

--
-- Table structure for table `profile_picture`
--

CREATE TABLE `profile_picture` (
  `user_id` int(11) NOT NULL,
  `path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `profile_picture`
--

INSERT INTO `profile_picture` (`user_id`, `path`) VALUES
(3, 'uploads/1748642108_gfrdfgerte.bmp'),
(8, 'uploads/1748698338_ProjektTest copy.jpg'),
(11, 'uploads/1748785930__MG_0002.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `status` enum('active','completed') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `user_id`, `title`, `description`, `created_at`, `status`) VALUES
(7, 3, 'Snimanje SAŠA', 'Snimanje filma E moj Saša', '2025-05-30 20:52:13', 'completed'),
(8, 3, 'Snimanje Nada - TiMater', 'Snimanje pjesme Nada benda Ti Mater', '2025-05-30 23:22:43', 'active'),
(9, 6, 'Snimanje pjesme', 'Snimanje cijelog benda', '2025-05-30 23:52:55', 'completed'),
(10, 8, 'Završni part 3', 'Lorem ipsum', '2025-05-31 15:33:45', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `google_id` varchar(50) DEFAULT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `surname` varchar(250) NOT NULL,
  `dateOfBirth` varchar(250) NOT NULL,
  `phone` varchar(250) NOT NULL,
  `address` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `country` varchar(250) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_croatian_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `google_id`, `email`, `password`, `name`, `surname`, `dateOfBirth`, `phone`, `address`, `city`, `country`, `role`) VALUES
(3, '112043254537455664022', 'sablja04@gmail.com', '$2y$10$J0CwDURXQhZOzWAABtnNJu1aVws8xr0CzvBs.AWHRoGgCi9Janjh2', 'Lovro', 'Sabljak', '2004-06-09', '0915610895', 'K.Š.Đalskog, 3a', 'Zaprešić', 'Hrvatska', 'user'),
(5, NULL, 'ivan.admin@example.com', '$2y$10$LpQTU48ODOGlBol86n9jnuAJ8AvyDt3BCltlWLB1c3OF9NOmi0DMK', 'Ivan', 'Horvat', '1980-01-01', '0912345678', 'Ulica 1', 'Zagreb', 'Hrvatska', 'admin'),
(6, NULL, 'marko@gmail.com', '$2y$10$9SU.tHiJP3U3/nC7NE3afOpttq6.h5SNJabdq5knpOJkrlDv6LHVG', 'Marko', 'Markic', '1999-01-01', '101010101', 'Ljudevita Gaja 62', 'Zaprešić', 'Hrvatska', 'user'),
(8, NULL, 'luka.juha1@gmail.com', '$2y$10$qS2rKRhAW3rWIxy.jXk4OefLBpbzTBpNXNW7OClQwqxeFcds3BlBm', 'Luka', 'Juha', '2004-10-12', '0957518188', 'Dragutina Tadijanovića, 6', 'Zaprešić', 'Hrvatska', 'user'),
(11, '100783856307749883670', 'sabljak.skola@gmail.com', '', 'Lovro', 'Sabljak', '', '', '', '', '', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsletter_subscribers`
--
ALTER TABLE `newsletter_subscribers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `portfolio_images`
--
ALTER TABLE `portfolio_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `portfolio_item_id` (`portfolio_item_id`);

--
-- Indexes for table `portfolio_items`
--
ALTER TABLE `portfolio_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_picture`
--
ALTER TABLE `profile_picture`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `google_id` (`google_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `newsletter_subscribers`
--
ALTER TABLE `newsletter_subscribers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `portfolio_images`
--
ALTER TABLE `portfolio_images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `portfolio_items`
--
ALTER TABLE `portfolio_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `portfolio_images`
--
ALTER TABLE `portfolio_images`
  ADD CONSTRAINT `portfolio_images_ibfk_1` FOREIGN KEY (`portfolio_item_id`) REFERENCES `portfolio_items` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `profile_picture`
--
ALTER TABLE `profile_picture`
  ADD CONSTRAINT `profile_picture_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`ID`) ON DELETE CASCADE;

--
-- Constraints for table `projects`
--
ALTER TABLE `projects`
  ADD CONSTRAINT `projects_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`ID`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
session_start();

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    die("Email i lozinka su obavezni.");
}

$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    die("Greška u pripremi upita: " . $conn->error);
}

$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();

    if (password_verify($password, $user['password'])) {
        $_SESSION['user'] = [
            'name' => $user['name'],
            'surname' => $user['surname'],
            'email' => $user['email'],
            'dateOfBirth' => $user['dateOfBirth'],
            'phone' => $user['phone'],
            'address' => $user['address'],
            'city' => $user['city'],
            'country' => $user['country'],
            'role' => $user['role']
        ];

        if ($user['role'] === 'admin') {
            header("Location: admin_dash.php");
        } else {
            header("Location: user.php");
        }
        exit;
    } else {
        echo "Pogrešna lozinka.";
    }
} else {
    echo "Korisnik ne postoji.";
}

$stmt->close();
$conn->close();
?>

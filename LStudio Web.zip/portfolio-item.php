<?php
$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$project_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($project_id <= 0) {
    die("Neispravan ID projekta.");
}

$stmt = $conn->prepare("SELECT title, description FROM portfolio_items WHERE id = ?");
$stmt->bind_param("i", $project_id);
$stmt->execute();
$result = $stmt->get_result();
$project = $result->fetch_assoc();
$stmt->close();

if (!$project) {
    die("Projekt nije pronađen.");
}

$stmt = $conn->prepare("SELECT image_path FROM portfolio_images WHERE portfolio_item_id = ? ORDER BY id ASC");
$stmt->bind_param("i", $project_id);
$stmt->execute();
$result = $stmt->get_result();
$images = [];
while ($row = $result->fetch_assoc()) {
    $images[] = $row['image_path'];
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
    <?php include 'head.php'; ?>
    <body class="d-flex flex-column h-100">
        <main class="flex-shrink-0">

            <?php include 'nav.php'; ?>

            <section class="py-5">
                <div class="container px-5 my-5">
                    <div class="row gx-5 justify-content-center">
                        <div class="col-lg-6">
                            <div class="text-center mb-5">
                                <h1 class="fw-bolder"><?= htmlspecialchars($project['title']) ?></h1>
                                <p class="lead fw-normal text-muted mb-0"><?= nl2br(htmlspecialchars($project['description'])) ?></p>
                            </div>
                        </div>
                    </div>

                    <?php if (!empty($images)): ?>

                        <div class="row gx-5 mb-5">
                            <div class="col-12">
                                <img class="img-fluid rounded-3" src="<?= htmlspecialchars($images[0]) ?>" alt="<?= htmlspecialchars($project['title']) ?>" />
                            </div>
                        </div>

                        <?php if (count($images) > 1): ?>

                        <div class="row gx-5">
                            <?php

                                for ($i = 1; $i < count($images); $i++):
                            ?>
                            <div class="col-lg-6 mb-5">
                                <img class="img-fluid rounded-3" src="<?= htmlspecialchars($images[$i]) ?>" alt="<?= htmlspecialchars($project['title']) . " - image " . $i ?>" />
                            </div>
                            <?php endfor; ?>
                        </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <p class="text-center text-muted">Nema dostupnih slika za ovaj projekt.</p>
                    <?php endif; ?>

                    <div class="row gx-5 justify-content-center">
                        <div class="col-lg-6">
                            <div class="text-center mb-5">
                                <a class="btn btn-primary" href="portfolio-overview.php">Povratak na portfolio</a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <!-- Footer-->
        <?php include 'footer.php'; ?>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>

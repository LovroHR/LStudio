<?php
session_start();
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$items = $conn->query("SELECT * FROM portfolio_items ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body class="d-flex flex-column min-vh-100">
<main class="flex-grow-1">
    <?php include 'nav.php'; ?>

    <div class="container py-5">
        <h1 class="mb-4">Uredi Portfolio</h1>
        <a href="portfolio_add.php" class="btn btn-primary mb-3">Dodaj novu stavku</a>

        <?php while ($item = $items->fetch_assoc()): ?>
            <div class="card mb-4">
                <div class="card-body">
                    <h5 class="card-title"><?= htmlspecialchars($item['title']) ?></h5>
                    <p class="card-text"><?= htmlspecialchars($item['description']) ?></p>
                    <a href="portfolio_update.php?id=<?= $item['id'] ?>" class="btn btn-warning btn-sm">Uredi</a>
                    <a href="portfolio_delete.php?id=<?= $item['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Jeste li sigurni da želite obrisati ovu stavku?')">Obriši</a>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</main>

<?php include 'footer.php'; ?>
</body>
</html>

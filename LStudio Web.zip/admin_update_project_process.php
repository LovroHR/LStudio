<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Neispravan zahtjev.");
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

$project_id = intval($_POST['project_id']);
$title = trim($_POST['title']);
$description = trim($_POST['description']);
$status = $_POST['status'] === 'completed' ? 'completed' : 'active'; 

if (empty($title) || empty($description)) {
    die("Naslov i opis su obavezni.");
}

// Ažuriraj projekt
$stmt = $conn->prepare("UPDATE projects SET title = ?, description = ?, status = ? WHERE id = ?");
$stmt->bind_param("sssi", $title, $description, $status, $project_id);

if ($stmt->execute()) {
    header("Location: admin_dash.php?msg=Projekt ažuriran");
    exit;
} else {
    echo "Greška pri ažuriranju projekta: " . $stmt->error;
}

$stmt->close();
$conn->close();

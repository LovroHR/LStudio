<?php
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$conn = new mysqli("localhost", "root", "", "lstudio baza");
if ($conn->connect_error) {
    die("Greška u povezivanju s bazom: " . $conn->connect_error);
}

if (!isset($_GET['user_id'])) {
    die("Nedostaje ID korisnika.");
}

$userId = intval($_GET['user_id']);

$stmtUser = $conn->prepare("SELECT id, name, surname FROM users WHERE id = ? AND role = 'user'");
$stmtUser->bind_param("i", $userId);
$stmtUser->execute();
$resultUser = $stmtUser->get_result();

if ($resultUser->num_rows !== 1) {
    die("Korisnik nije pronađen.");
}

$user = $resultUser->fetch_assoc();
$stmtUser->close();
?>

<!DOCTYPE html>
<html lang="hr">
<?php include 'head.php'; ?>
<body class="d-flex flex-column h-100">
<?php include 'nav.php'; ?>

<section class="py-5">
    <div class="container mt-5">
    <h2>Dodaj novi projekt za: <?= htmlspecialchars($user['name'] . ' ' . $user['surname']) ?></h2>

    <form action="admin_add_project_process.php" method="POST">
        <input type="hidden" name="user_id" value="<?= $user['id'] ?>">

        <div class="mb-3">
            <label for="title" class="form-label">Naslov projekta</label>
            <input type="text" class="form-control" id="title" name="title" required>
        </div>

        <div class="mb-3">
            <label for="description" class="form-label">Opis projekta</label>
            <textarea class="form-control" id="description" name="description" rows="4" required></textarea>
        </div>

        <div class="mb-3">
            <label for="status" class="form-label">Status</label>
            <select class="form-select" id="status" name="status" required>
                <option value="active" selected>Aktivan</option>
                <option value="completed">Završen</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Dodaj projekt</button>
        <a href="admin_dash.php" class="btn btn-secondary">Natrag</a>
    </form>
</div>
</section>



<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php $conn->close(); ?>


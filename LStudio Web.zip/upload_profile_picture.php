<?php
session_start();

if (!isset($_SESSION['user']['id'])) {
    header("Location: login.php");
    exit;
}

$userId = $_SESSION['user']['id'];

if (isset($_FILES['profilePicture']) && $_FILES['profilePicture']['error'] === UPLOAD_ERR_OK) {
    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $fileTmpPath = $_FILES['profilePicture']['tmp_name'];
    $originalName = basename($_FILES['profilePicture']['name']);
    $fileExt = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    $allowedExts = ['jpg', 'jpeg', 'png', 'gif'];

    if (!in_array($fileExt, $allowedExts)) {
        die("Dozvoljeni formati su: jpg, jpeg, png, gif.");
    }

    $newFileName = uniqid('profile_', true) . '.' . $fileExt;
    $destPath = $uploadDir . $newFileName;

    if (move_uploaded_file($fileTmpPath, $destPath)) {
        $conn = new mysqli("localhost", "root", "", "lstudio baza");
        if ($conn->connect_error) {
            die("Greška u povezivanju s bazom: " . $conn->connect_error);
        }

        $conn->query("DELETE FROM profile_picture WHERE user_id = $userId");

        $stmt = $conn->prepare("INSERT INTO profile_picture (user_id, filename) VALUES (?, ?)");
        $stmt->bind_param("is", $userId, $newFileName);
        $stmt->execute();

        $stmt->close();
        $conn->close();

        header("Location: user.php");
        exit;
    } else {
        die("Greška pri spremanju slike.");
    }
} else {
    die("Greška pri uploadu slike.");
}
?>

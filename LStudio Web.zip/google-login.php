<?php
require_once 'vendor/autoload.php';

$client = new Google_Client();
$client->setClientId('762944395886-vm6nhkj6gfqipc1b531shvfkm69onjoh.apps.googleusercontent.com');
$client->setClientSecret('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');
$client->setRedirectUri('http://localhost/bootstrap/google-callback.php');
$client->addScope('email');
$client->addScope('profile');

header('Location: ' . $client->createAuthUrl());
exit();

<!DOCTYPE html>
<html lang="en">
    <?php include 'head.php'; ?>
    <body class="d-flex flex-column h-100">
        <main class="flex-shrink-0">
            <?php include 'nav.php'; ?>

            <section class="py-5">
                <div class="container px-5">
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="card shadow-lg border-0 rounded-3">
                                <div class="card-body p-4">
                                    <h2 class="text-center mb-4">Prijava</h2>

                                    <form action="login_process.php" method="POST">
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="email" type="email" name="email" placeholder="name@example.com" required />
                                            <label for="email">Email adresa</label>
                                        </div>
                                        <div class="form-floating mb-3">
                                            <input class="form-control" id="password" type="password" name="password" placeholder="Lozinka" required />
                                            <label for="password">Lozinka</label>
                                        </div>
                                        <div class="d-grid">
                                            <button class="btn btn-primary btn-lg" type="submit">Prijavi se</button>
                                        </div>
                                    </form>

                                    <hr class="my-4">
                                    <div class="d-grid mb-3">
                                        <a href="google-login.php" class="btn btn-danger btn-lg">
                                            <i class="bi bi-google"></i> Prijava putem Googlea
                                        </a>
                                    </div>

                                    <p class="text-center small">
                                        Nemaš račun? <a href="register.php">Registriraj se</a>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </main>
        <!-- Footer-->
        <?php include 'footer.php'; ?>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>

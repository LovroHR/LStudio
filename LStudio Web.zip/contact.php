<!DOCTYPE html>
<html lang="en">
    <?php include 'head.php'; ?>
    <body class="d-flex flex-column">
        <main class="flex-shrink-0">

            <?php include 'nav.php'; ?>

            <section class="py-5">
                <div class="container px-5">

                    <div class="bg-light rounded-3 py-5 px-4 px-md-5 mb-5">
                        <div class="text-center mb-5">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-envelope"></i></div>
                            <h1 class="fw-bolder">Kontaktirajte nas!</h1>
                            <p class="lead fw-normal text-muted mb-0">Želimo razgovarati s Vama!</p>
                        </div>
                        <div class="row gx-5 justify-content-center">
                            <div class="col-lg-8 col-xl-6">
                                <form id="contactForm" action="https://formspree.io/f/mkgrddba" method="POST">
                                    <div class="form-floating mb-3">
                                        <input class="form-control" id="name" name="name" type="text" placeholder="Unesite ime i prezime..." required />
                                        <label for="name">Ime i prezime</label>
                                    </div>

                                    <div class="form-floating mb-3">
                                        <input class="form-control" id="email" name="email" type="email" placeholder="ime@primjer.com" required />
                                        <label for="email">Email adresa</label>
                                    </div>

                                    <div class="form-floating mb-3">
                                        <input class="form-control" id="phone" name="phone" type="tel" placeholder="091 123 4567" required />
                                        <label for="phone">Broj telefona</label>
                                    </div>

                                    <div class="form-floating mb-3">
                                        <textarea class="form-control" id="message" name="message" placeholder="Upišite poruku..." style="height: 10rem" required></textarea>
                                        <label for="message">Poruka</label>
                                    </div>

                                    <div class="d-grid">
                                        <button class="btn btn-primary btn-lg" id="submitButton" type="submit" disabled>Pošalji</button>
                                    </div>
                                </form>

                    <script>
                    document.addEventListener("DOMContentLoaded", function () {
                        const form = document.getElementById("contactForm");
                        const submitBtn = document.getElementById("submitButton");

                        const inputs = form.querySelectorAll("input, textarea");

                        function checkFormValidity() {
                            let allFilled = true;
                            inputs.forEach(input => {
                                if (!input.value.trim()) {
                                    allFilled = false;
                                }
                            });
                            submitBtn.disabled = !allFilled;
                        }

                        inputs.forEach(input => {
                            input.addEventListener("input", checkFormValidity);
                        });
                    });
                    </script>

                            </div>
                        </div>
                    </div>
                    <!-- Contact cards-->
                    <div class="row gx-5 row-cols-1 row-cols-md-2 py-5 justify-content-center text-center">
                        <div class="col mb-4">
                            <a href="mailto:support@lstudio.hr" class="text-decoration-none text-dark">
                                <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3 mx-auto" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                                    <i class="bi bi-envelope fs-3"></i>
                                </div>
                                <div class="h5 mb-2">Email</div>
                                <p class="text-muted mb-0">support@lstudio.hr</p>
                            </a>
                        </div>
                        <div class="col mb-4">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3 mx-auto" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center;">
                                <i class="bi bi-telephone fs-3"></i>
                            </div>
                            <div class="h5">Telefon</div>
                            <p class="text-muted mb-0">+385 99 123 4567</p>
                        </div>
                    </div>
                </div>
            </section>
        </main>

        <?php include 'footer.php'; ?>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="js/scripts.js"></script>
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
